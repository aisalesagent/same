import { IdeLayout } from "@/components/ide/layout";

export default function Home() {
  return <IdeLayout />;
}
