"use client"

import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Terminal as TerminalIcon, X } from "lucide-react"
import { useState } from "react"

type TerminalLine = {
  id: string
  type: "input" | "output"
  content: string
}

type TerminalTab = {
  id: string
  name: string
  lines: TerminalLine[]
}

export function Terminal() {
  const [activeTab, setActiveTab] = useState("terminal1")
  const [terminalTabs, setTerminalTabs] = useState<TerminalTab[]>([
    {
      id: "terminal1",
      name: "Terminal",
      lines: [
        { id: "1", type: "output", content: "Welcome to Same.new Terminal" },
        { id: "2", type: "output", content: "Node.js v20.17.22 on Linux 5.15.0" },
        { id: "3", type: "input", content: "ls -la" },
        {
          id: "4",
          type: "output",
          content: `total 40
drwxr-xr-x  5 user user 4096 Mar 28 13:45 .
drwxr-xr-x 18 user user 4096 Mar 28 13:40 ..
drwxr-xr-x  8 user user 4096 Mar 28 13:45 .git
-rw-r--r--  1 user user  257 Mar 28 13:45 .gitignore
-rw-r--r--  1 user user  825 Mar 28 13:45 README.md
-rw-r--r--  1 user user  364 Mar 28 13:45 next-env.d.ts
-rw-r--r--  1 user user  857 Mar 28 13:45 next.config.js
-rw-r--r--  1 user user  851 Mar 28 13:45 package.json
drwxr-xr-x  3 user user 4096 Mar 28 13:45 src
-rw-r--r--  1 user user 1644 Mar 28 13:45 tailwind.config.ts
-rw-r--r--  1 user user  672 Mar 28 13:45 tsconfig.json`,
        },
        { id: "5", type: "input", content: "npm run dev" },
        { id: "6", type: "output", content: "Starting the development server..." },
        { id: "7", type: "output", content: "Listening on http://localhost:3000" },
      ],
    },
    {
      id: "terminal2",
      name: "Output",
      lines: [
        { id: "1", type: "output", content: "Output terminal for build logs and other processes" },
      ],
    },
  ])

  const closeTab = (id: string) => {
    const newTabs = terminalTabs.filter(tab => tab.id !== id)
    setTerminalTabs(newTabs)

    if (activeTab === id && newTabs.length > 0) {
      setActiveTab(newTabs[0].id)
    }
  }

  return (
    <div className="h-full flex flex-col bg-[color:hsl(var(--terminal-bg))] text-[color:hsl(var(--terminal-text))] overflow-hidden">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
        <div className="border-b border-gray-800">
          <TabsList className="bg-gray-900 h-9 px-2">
            {terminalTabs.map(tab => (
              <TabsTrigger
                key={tab.id}
                value={tab.id}
                className="flex items-center h-7 px-3 data-[state=active]:bg-[color:hsl(var(--terminal-bg))] data-[state=active]:text-[color:hsl(var(--terminal-text))]"
              >
                <TerminalIcon className="h-3 w-3 mr-2" />
                <span>{tab.name}</span>
                <button
                  className="ml-2 rounded-full hover:bg-gray-800 p-1"
                  onClick={(e) => {
                    e.stopPropagation()
                    closeTab(tab.id)
                  }}
                >
                  <X className="h-3 w-3" />
                </button>
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        {terminalTabs.map(tab => (
          <TabsContent key={tab.id} value={tab.id} className="flex-grow p-0 m-0">
            <ScrollArea className="h-full">
              <div className="p-3 terminal-text">
                {tab.lines.map(line => (
                  <div key={line.id} className="py-0.5">
                    {line.type === "input" ? (
                      <div className="flex">
                        <span className="text-green-500 mr-2">$</span>
                        <span>{line.content}</span>
                      </div>
                    ) : (
                      <div className="text-gray-300">{line.content}</div>
                    )}
                  </div>
                ))}
                <div className="flex mt-1">
                  <span className="text-green-500 mr-2">$</span>
                  <div className="h-4 w-2 bg-gray-300 animate-pulse"></div>
                </div>
              </div>
            </ScrollArea>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
