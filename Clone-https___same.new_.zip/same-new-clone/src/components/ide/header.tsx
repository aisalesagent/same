"use client"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu"
import {
  Code,
  FileText,
  Github,
  LayoutDashboard,
  Zap,
  User
} from "lucide-react"

export function IdeHeader() {
  return (
    <header className="h-12 flex items-center bg-background border-b px-4">
      <div className="flex items-center space-x-4">
        <div className="flex items-center mr-6">
          <Code className="h-5 w-5 mr-2" />
          <span className="text-base font-medium">Same.new</span>
        </div>
        <Button variant="ghost" size="sm" className="h-8 text-muted-foreground text-sm font-normal">
          <FileText className="h-4 w-4 mr-2" />
          Files
        </Button>
        <Button variant="ghost" size="sm" className="h-8 text-muted-foreground text-sm font-normal">
          <Github className="h-4 w-4 mr-2" />
          GitHub
        </Button>
        <Button variant="ghost" size="sm" className="h-8 text-muted-foreground text-sm font-normal">
          <LayoutDashboard className="h-4 w-4 mr-2" />
          Dashboard
        </Button>
      </div>

      <div className="ml-auto flex items-center space-x-3">
        <Button variant="outline" size="sm" className="h-8 px-3 bg-black text-white border-black hover:bg-black/90 hover:text-white">
          <Zap className="h-4 w-4 mr-2 text-yellow-400" />
          Deploy
        </Button>
        <Button variant="ghost" size="icon" className="rounded-full h-8 w-8">
          <User className="h-4 w-4" />
        </Button>
      </div>
    </header>
  )
}
