"use client"

import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Send, Bot, User, Paperclip, RefreshCw } from "lucide-react"
import { useState } from "react"

type Message = {
  id: string
  role: "human" | "assistant"
  content: string
  timestamp: Date
}

export function AiChat() {
  const [input, setInput] = useState("")
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Hello! I'm Claude 3.7 Sonnet. I'm a powerful agentic AI coding assistant. How can I help you today?",
      timestamp: new Date(),
    },
  ])

  const sendMessage = () => {
    if (!input.trim()) return

    // Add user message
    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: "human",
      content: input,
      timestamp: new Date(),
    }

    setMessages(prev => [...prev, userMessage])
    setInput("")

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content: getMockResponse(input),
        timestamp: new Date(),
      }
      setMessages(prev => [...prev, aiMessage])
    }, 1000)
  }

  const getMockResponse = (userInput: string) => {
    const responses = [
      "I'll help you with that! Let's start by examining the code structure.",
      "Looking at your request, I think we can approach this by creating a new component.",
      "Let me analyze this code for you. There might be a more efficient way to achieve what you're looking for.",
      "I'd be happy to help debug this issue. Let's look at where the error might be coming from.",
      "I can help optimize this function. Let me show you how we can refactor it.",
    ]

    return responses[Math.floor(Math.random() * responses.length)]
  }

  return (
    <div className="h-full flex flex-col overflow-hidden bg-background">
      <div className="p-2 border-b flex items-center justify-between">
        <div className="flex items-center">
          <Bot className="h-5 w-5 mr-2 text-primary" />
          <h2 className="font-semibold text-sm">Claude 3.7 Sonnet</h2>
        </div>
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <RefreshCw className="h-4 w-4" />
        </Button>
      </div>

      <ScrollArea className="flex-grow">
        <div className="p-4 space-y-6">
          {messages.map(message => (
            <div key={message.id} className="flex">
              <div
                className={`rounded-full h-8 w-8 flex items-center justify-center ${
                  message.role === 'assistant' ? 'bg-primary/10 text-primary' : 'bg-muted'
                } mr-3 mt-0.5 flex-shrink-0`}
              >
                {message.role === 'assistant' ? (
                  <Bot className="h-5 w-5" />
                ) : (
                  <User className="h-5 w-5" />
                )}
              </div>
              <div className="flex-grow">
                <div className="font-medium text-sm">
                  {message.role === 'assistant' ? 'Claude' : 'You'}
                </div>
                <div className="mt-1 text-sm">
                  {message.content}
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      <div className="p-4 border-t">
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="icon" className="flex-shrink-0">
            <Paperclip className="h-4 w-4" />
          </Button>
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Message Claude..."
            className="min-h-10 max-h-40"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                sendMessage()
              }
            }}
          />
          <Button
            className="flex-shrink-0"
            disabled={!input.trim()}
            onClick={sendMessage}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
