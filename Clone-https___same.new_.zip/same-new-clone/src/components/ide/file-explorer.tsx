"use client"

import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { ChevronDown, ChevronRight, File, Folder, FolderOpen, Plus, Search } from "lucide-react"
import { useState } from "react"

type FileNode = {
  id: string
  name: string
  type: "file" | "folder"
  children?: FileNode[]
  expanded?: boolean
}

const initialFiles: FileNode[] = [
  {
    id: "1",
    name: "src",
    type: "folder",
    expanded: true,
    children: [
      {
        id: "2",
        name: "components",
        type: "folder",
        expanded: true,
        children: [
          { id: "3", name: "button.tsx", type: "file" },
          { id: "4", name: "card.tsx", type: "file" },
          { id: "5", name: "header.tsx", type: "file" },
        ],
      },
      {
        id: "6",
        name: "app",
        type: "folder",
        children: [
          { id: "7", name: "page.tsx", type: "file" },
          { id: "8", name: "layout.tsx", type: "file" },
        ],
      },
      { id: "9", name: "utils.ts", type: "file" },
    ],
  },
  {
    id: "10",
    name: "public",
    type: "folder",
    children: [
      { id: "11", name: "favicon.ico", type: "file" },
      { id: "12", name: "logo.svg", type: "file" },
    ],
  },
  { id: "13", name: "package.json", type: "file" },
  { id: "14", name: "tsconfig.json", type: "file" },
  { id: "15", name: "next.config.js", type: "file" },
]

export function FileExplorer() {
  const [files, setFiles] = useState<FileNode[]>(initialFiles)
  const [activeFile, setActiveFile] = useState<string | null>(null)

  const toggleFolder = (id: string) => {
    setFiles(prevFiles => {
      const updateNode = (nodes: FileNode[]): FileNode[] => {
        return nodes.map(node => {
          if (node.id === id) {
            return { ...node, expanded: !node.expanded }
          }
          if (node.children) {
            return { ...node, children: updateNode(node.children) }
          }
          return node
        })
      }
      return updateNode(prevFiles)
    })
  }

  const renderFileTree = (nodes: FileNode[], level = 0) => {
    return nodes.map(node => (
      <div key={node.id}>
        <div
          className={`flex items-center py-1 px-2 hover:bg-accent hover:text-accent-foreground rounded-md cursor-pointer ${
            activeFile === node.id ? "bg-accent text-accent-foreground" : ""
          }`}
          style={{ paddingLeft: `${level * 12 + 8}px` }}
          onClick={() => {
            if (node.type === "folder") {
              toggleFolder(node.id)
            } else {
              setActiveFile(node.id)
            }
          }}
        >
          {node.type === "folder" ? (
            <div className="mr-1 h-4 w-4">
              {node.expanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            </div>
          ) : (
            <div className="mr-1 w-4"></div>
          )}
          {node.type === "folder" ? (
            node.expanded ? (
              <FolderOpen className="mr-2 h-4 w-4 text-blue-500" />
            ) : (
              <Folder className="mr-2 h-4 w-4 text-blue-500" />
            )
          ) : (
            <File className="mr-2 h-4 w-4 text-gray-500" />
          )}
          <span className="text-sm truncate">{node.name}</span>
        </div>
        {node.type === "folder" && node.expanded && node.children && (
          <div>{renderFileTree(node.children, level + 1)}</div>
        )}
      </div>
    ))
  }

  return (
    <div className="h-full flex flex-col border-r">
      <div className="p-2 border-b flex items-center justify-between">
        <h2 className="font-semibold text-sm">Explorer</h2>
        <Button variant="ghost" size="icon" className="h-6 w-6">
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <div className="p-2">
        <div className="relative">
          <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search files..."
            className="w-full rounded-md bg-muted pl-8 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
      </div>
      <ScrollArea className="flex-grow">
        <div className="p-2">{renderFileTree(files)}</div>
      </ScrollArea>
    </div>
  )
}
