"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useState } from "react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { X } from "lucide-react"

// Mock code sample with TypeScript syntax
const mockTypeScriptCode = `import { useState, useEffect } from 'react'

export function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T) => void] {
  // State to store our value
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      // Get from local storage by key
      const item = window.localStorage.getItem(key)
      // Parse stored json or if none return initialValue
      return item ? JSON.parse(item) : initialValue
    } catch (error) {
      // If error also return initialValue
      console.log(error)
      return initialValue
    }
  })

  // Return a wrapped version of useState's setter function that
  // persists the new value to localStorage.
  const setValue = (value: T) => {
    try {
      // Allow value to be a function so we have same API as useState
      const valueToStore =
        value instanceof Function ? value(storedValue) : value
      // Save state
      setStoredValue(valueToStore)
      // Save to local storage
      window.localStorage.setItem(key, JSON.stringify(valueToStore))
    } catch (error) {
      // A more advanced implementation would handle the error case
      console.log(error)
    }
  }

  return [storedValue, setValue]
}`

// Mock HTML code
const mockHTMLCode = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Web App</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <header>
    <nav>
      <ul>
        <li><a href="#home">Home</a></li>
        <li><a href="#about">About</a></li>
        <li><a href="#contact">Contact</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <section id="home">
      <h1>Welcome to My Web App</h1>
      <p>This is a simple HTML template.</p>
    </section>
  </main>

  <footer>
    <p>&copy; 2025 My Web App. All rights reserved.</p>
  </footer>

  <script src="app.js"></script>
</body>
</html>`

interface OpenTab {
  id: string
  name: string
  content: string
  language: "typescript" | "html" | "css" | "javascript"
}

export function CodeEditor() {
  const [activeTab, setActiveTab] = useState("tab1")
  const [openTabs, setOpenTabs] = useState<OpenTab[]>([
    {
      id: "tab1",
      name: "useLocalStorage.ts",
      content: mockTypeScriptCode,
      language: "typescript",
    },
    {
      id: "tab2",
      name: "index.html",
      content: mockHTMLCode,
      language: "html",
    },
  ])

  const closeTab = (id: string) => {
    const newTabs = openTabs.filter(tab => tab.id !== id)
    setOpenTabs(newTabs)

    if (activeTab === id && newTabs.length > 0) {
      setActiveTab(newTabs[0].id)
    }
  }

  // Function to generate line numbers
  const renderLineNumbers = (code: string) => {
    const lineCount = code.split("\n").length
    return Array.from({ length: lineCount }, (_, i) => i + 1)
  }

  // Function to add syntax highlighting classes to code
  const highlightCode = (code: string, language: string) => {
    // This is a simple mockup of syntax highlighting
    // In a real app, you'd use a library like Prism or highlight.js
    if (language === 'typescript' || language === 'javascript') {
      return code
        .replace(/\/\/(.*)/g, '<span class="token comment">//$1</span>')
        .replace(/function/g, '<span class="token keyword">function</span>')
        .replace(/const|let|var|return|export|import|from/g, '<span class="token keyword">$&</span>')
        .replace(/(\w+)\(/g, '<span class="token function">$1</span>(')
        .replace(/"([^"]*)"/g, '<span class="token string">"$1"</span>')
        .replace(/'([^']*)'/g, '<span class="token string">\'$1\'</span>')
        .replace(/&lt;([A-Za-z]+)&gt;/g, '&lt;<span class="token class-name">$1</span>&gt;')
    } else if (language === 'html') {
      return code
        .replace(/&lt;([\/]?)([a-zA-Z0-9]+)/g, '&lt;$1<span class="token tag">$2</span>')
        .replace(/([a-zA-Z0-9\-]+)=/g, '<span class="token property">$1</span>=')
        .replace(/"([^"]*)"/g, '<span class="token string">"$1"</span>')
    }
    return code
  }

  return (
    <div className="h-full flex flex-col bg-background code-editor">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
        <div className="border-b">
          <TabsList className="h-10 px-2">
            {openTabs.map(tab => (
              <TabsTrigger
                key={tab.id}
                value={tab.id}
                className="flex items-center h-8 px-3 relative"
              >
                <span>{tab.name}</span>
                <button
                  className="ml-2 rounded-full hover:bg-muted p-1"
                  onClick={(e) => {
                    e.stopPropagation()
                    closeTab(tab.id)
                  }}
                >
                  <X className="h-3 w-3" />
                </button>
              </TabsTrigger>
            ))}
          </TabsList>
        </div>
        {openTabs.map(tab => (
          <TabsContent key={tab.id} value={tab.id} className="flex-grow relative flex overflow-hidden">
            <div className="w-12 bg-muted flex-shrink-0 py-2 text-right text-xs text-muted-foreground font-mono border-r">
              {renderLineNumbers(tab.content).map(num => (
                <div key={num} className="px-2 line-number">{num}</div>
              ))}
            </div>
            <ScrollArea className="flex-grow">
              <pre className="p-2 text-sm font-mono">
                <code
                  dangerouslySetInnerHTML={{
                    __html: highlightCode(
                      tab.content
                        .replace(/</g, '&lt;')
                        .replace(/>/g, '&gt;'),
                      tab.language
                    )
                  }}
                />
              </pre>
            </ScrollArea>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
