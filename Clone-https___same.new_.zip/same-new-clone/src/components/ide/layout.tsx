"use client"

import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable"
import { IdeHeader } from "./header"
import { FileExplorer } from "./file-explorer"
import { CodeEditor } from "./code-editor"
import { Terminal } from "./terminal"
import { AiChat } from "./ai-chat"

export function IdeLayout() {
  return (
    <div className="h-screen flex flex-col">
      <IdeHeader />
      <div className="flex-grow overflow-hidden">
        <ResizablePanelGroup direction="horizontal">
          {/* Left sidebar - File Explorer */}
          <ResizablePanel defaultSize={20} minSize={15} maxSize={30}>
            <FileExplorer />
          </ResizablePanel>

          <ResizableHandle withHandle />

          {/* Center - Code editor and terminal */}
          <ResizablePanel defaultSize={55}>
            <ResizablePanelGroup direction="vertical">
              {/* Code Editor */}
              <ResizablePanel defaultSize={70}>
                <CodeEditor />
              </ResizablePanel>

              <ResizableHandle withHandle />

              {/* Terminal */}
              <ResizablePanel defaultSize={30}>
                <Terminal />
              </ResizablePanel>
            </ResizablePanelGroup>
          </ResizablePanel>

          <ResizableHandle withHandle />

          {/* Right sidebar - AI Chat */}
          <ResizablePanel defaultSize={25} minSize={20} maxSize={40}>
            <AiChat />
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>
    </div>
  )
}
