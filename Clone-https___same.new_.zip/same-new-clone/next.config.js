/**
 * @type {import('next').NextConfig}
 */

const nextConfig = {
  output: 'export',
  distDir: 'out',
  images: {
    unoptimized: true,
  },
  /**
   * It can be helpful for local testing to disable React Strict Mode.
   * This can be useful when developing forms where you want to persist form state between refreshes.
   */
  reactStrictMode: true,
  /*
   * These specific transforms (class_properties, object_rest_spread) are recommended by MUI's
   * installation instructions. They were originally used for migrating from v4 to v5.
   */
  experimental: {
    serverMinification: true,
    esmExternals: true,
  },
  serverExternalPackages: ["tailwindcss"],
  /*
   * Enable all transpilation for best support with multi-version dependencies.
   */
  transpilePackages: [
    "@babel/runtime",
    "@hookform/resolvers",
    "zod",
    "zod-validation-error",
    "sonner",
    "date-fns",
  ],
}

module.exports = nextConfig
