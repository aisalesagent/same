import Navbar from "@/components/navbar";
import SearchBar from "@/components/search-bar";
import ProjectCard from "@/components/project-card";
import { getProjects } from "@/lib/api";

export default async function Home() {
  // Fetch projects from the API
  const projects = await getProjects();

  return (
    <main className="min-h-screen">
      <Navbar />

      <section className="py-16 px-6 flex flex-col items-center justify-center">
        <h1 className="text-5xl font-bold text-center mb-8">Copy any UI</h1>
        <div className="w-full max-w-2xl mb-4">
          <SearchBar />
        </div>
        <p className="text-muted-foreground text-center">
          Prompt URL to make pixel perfect copies
        </p>
      </section>

      <section className="max-w-7xl mx-auto px-6 pb-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {projects.map((project) => (
            <ProjectCard
              key={project.id}
              id={project.id}
              imageSrc={project.imageSrc}
              userAvatarSrc={project.userAvatarSrc}
              timeAgo={project.timeAgo}
              title={project.title}
              promptUrl={project.promptUrl}
            />
          ))}
        </div>
      </section>

      <footer className="border-t py-6 text-center text-sm text-muted-foreground">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-center space-x-4">
            <a href="/terms-of-service" className="hover:underline">Terms of Service</a>
            <a href="/privacy" className="hover:underline">Privacy Policy</a>
          </div>
        </div>
      </footer>
    </main>
  );
}
