"use client";

import { useEffect } from "react";

export function ClientBody({
  children,
}: {
  children: React.ReactNode;
}) {
  useEffect(() => {
    console.log("Client-side rendering initialized");
  }, []);

  return <>{children}</>;
}
