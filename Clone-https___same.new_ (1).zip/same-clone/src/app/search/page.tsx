import Link from "next/link";
import { Metadata } from "next";
import Navbar from "@/components/navbar";
import SearchBar from "@/components/search-bar";
import ProjectCard from "@/components/project-card";
import { searchProjects } from "@/lib/api";

export const dynamic = 'force-dynamic'; // Ensure this page is not statically optimized

export async function generateMetadata({ searchParams }: { searchParams: { q: string } }): Promise<Metadata> {
  const query = searchParams.q || '';
  return {
    title: `Search results for "${query}" - Same`,
    description: `Search results for ${query} on Same.new`,
  };
}

export default async function SearchPage({ searchParams }: { searchParams: { q: string } }) {
  const query = searchParams.q || '';
  const { results, count } = await searchProjects(query);

  return (
    <main className="min-h-screen">
      <Navbar />

      <section className="py-10 px-6 max-w-7xl mx-auto">
        <div className="mb-8">
          <div className="w-full max-w-2xl mx-auto mb-8">
            <SearchBar />
          </div>

          <div className="text-center">
            <h1 className="text-2xl font-semibold mb-2">
              Search results for "{query}"
            </h1>
            <p className="text-muted-foreground">
              {count} {count === 1 ? 'result' : 'results'} found
            </p>
          </div>
        </div>

        {results.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
            {results.map((project) => (
              <ProjectCard
                key={project.id}
                id={project.id}
                imageSrc={project.imageSrc}
                userAvatarSrc={project.userAvatarSrc}
                timeAgo={project.timeAgo}
                title={project.title}
                promptUrl={project.promptUrl}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <h2 className="text-xl font-semibold mb-4">No results found</h2>
            <p className="text-muted-foreground mb-6">
              Try different keywords or browse all projects
            </p>
            <Link
              href="/"
              className="text-primary hover:underline"
            >
              Go back to home
            </Link>
          </div>
        )}
      </section>

      <footer className="border-t py-6 text-center text-sm text-muted-foreground mt-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-center space-x-4">
            <a href="/terms-of-service" className="hover:underline">Terms of Service</a>
            <a href="/privacy" className="hover:underline">Privacy Policy</a>
          </div>
        </div>
      </footer>
    </main>
  );
}
