import Link from "next/link";
import Navbar from "@/components/navbar";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <main className="min-h-screen">
      <Navbar />

      <div className="max-w-6xl mx-auto px-6 py-20 text-center">
        <h1 className="text-4xl font-bold mb-4">Page Not Found</h1>
        <p className="text-muted-foreground text-lg mb-8">
          Sorry, the page you're looking for doesn't exist or has been moved.
        </p>

        <div className="flex justify-center">
          <Button asChild size="lg">
            <Link href="/">Back to Home</Link>
          </Button>
        </div>
      </div>

      <footer className="border-t py-6 text-center text-sm text-muted-foreground mt-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-center space-x-4">
            <a href="/terms-of-service" className="hover:underline">Terms of Service</a>
            <a href="/privacy" className="hover:underline">Privacy Policy</a>
          </div>
        </div>
      </footer>
    </main>
  );
}
