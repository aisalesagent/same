import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Metadata } from "next";
import Navbar from "@/components/navbar";
import ProjectCard from "@/components/project-card";
import { Button } from "@/components/ui/button";
import { getProject, getProjectSuggestions } from "@/lib/api";
import { ChevronLeft } from "lucide-react";

interface ProjectPageProps {
  params: {
    id: string;
  };
}

export async function generateMetadata({ params }: ProjectPageProps): Promise<Metadata> {
  const id = parseInt(params.id);
  const project = await getProject(id);

  if (!project) {
    return {
      title: "Project Not Found - Same",
    };
  }

  return {
    title: `${project.title} - Same`,
    description: project.description || `Details for ${project.title} on Same.new`,
  };
}

export default async function ProjectPage({ params }: ProjectPageProps) {
  const id = parseInt(params.id);
  const project = await getProject(id);

  if (!project) {
    notFound();
  }

  // Get suggested projects
  const suggestions = await getProjectSuggestions(id);

  return (
    <main className="min-h-screen">
      <Navbar />

      <div className="max-w-6xl mx-auto px-6 py-10">
        <div className="mb-6">
          <Link href="/" className="inline-flex items-center text-muted-foreground hover:text-foreground">
            <ChevronLeft size={16} className="mr-1" />
            Back to All Projects
          </Link>
        </div>

        <div className="grid md:grid-cols-2 gap-10">
          <div className="relative aspect-[4/3] w-full rounded-lg overflow-hidden border shadow-md">
            <Image
              src={project.imageSrc}
              alt={project.title}
              fill
              className="object-cover"
            />
          </div>

          <div>
            <div className="flex items-center mb-6">
              {project.userAvatarSrc && (
                <div className="mr-4">
                  <Image
                    src={project.userAvatarSrc}
                    alt="User avatar"
                    width={48}
                    height={48}
                    className="rounded-full"
                  />
                </div>
              )}

              <div>
                <h1 className="text-3xl font-bold mb-2">{project.title}</h1>
                <span className="text-sm text-muted-foreground">{project.timeAgo}</span>
              </div>
            </div>

            {project.description && (
              <div className="mb-8">
                <h2 className="text-lg font-medium mb-2">Description</h2>
                <p className="text-muted-foreground">{project.description}</p>
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-primary hover:bg-primary/90">
                Use Prompt
              </Button>
              <Button size="lg" variant="outline">
                Clone This UI
              </Button>
            </div>
          </div>
        </div>

        {suggestions.length > 0 && (
          <div className="mt-20">
            <h2 className="text-2xl font-bold mb-6">You might also like</h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
              {suggestions.map((suggestion) => (
                <ProjectCard
                  key={suggestion.id}
                  id={suggestion.id}
                  imageSrc={suggestion.imageSrc}
                  userAvatarSrc={suggestion.userAvatarSrc}
                  timeAgo={suggestion.timeAgo}
                  title={suggestion.title}
                  promptUrl={suggestion.promptUrl}
                />
              ))}
            </div>
          </div>
        )}
      </div>

      <footer className="border-t py-6 text-center text-sm text-muted-foreground mt-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-center space-x-4">
            <a href="/terms-of-service" className="hover:underline">Terms of Service</a>
            <a href="/privacy" className="hover:underline">Privacy Policy</a>
          </div>
        </div>
      </footer>
    </main>
  );
}
