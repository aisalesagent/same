import { NextResponse } from 'next/server';
import { projects } from '@/lib/data';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get('q');

    if (!query) {
      return NextResponse.json({
        success: false,
        message: 'Query parameter is required'
      }, { status: 400 });
    }

    const queryLower = query.toLowerCase();

    // Filter projects based on the query
    const results = projects.filter(project =>
      project.title.toLowerCase().includes(queryLower) ||
      (project.description && project.description.toLowerCase().includes(queryLower))
    );

    return NextResponse.json({
      success: true,
      results,
      count: results.length,
      query
    }, { status: 200 });
  } catch (error) {
    return NextResponse.json({
      success: false,
      message: 'Failed to search projects',
      error: String(error)
    }, { status: 500 });
  }
}
