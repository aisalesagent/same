import { NextResponse } from 'next/server';
import { projects, Project } from '@/lib/data';

// GET all projects
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = searchParams.get('limit');
    const search = searchParams.get('search');

    let result = [...projects];

    // Filter projects if search param exists
    if (search) {
      const searchLower = search.toLowerCase();
      result = result.filter(project =>
        project.title.toLowerCase().includes(searchLower)
      );
    }

    // Limit results if limit param exists
    if (limit) {
      const limitNum = parseInt(limit);
      if (!isNaN(limitNum)) {
        result = result.slice(0, limitNum);
      }
    }

    return NextResponse.json({ projects: result }, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch projects' },
      { status: 500 }
    );
  }
}
