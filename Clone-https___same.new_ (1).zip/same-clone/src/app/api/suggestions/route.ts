import { NextResponse } from 'next/server';
import { projects } from '@/lib/data';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('projectId');
    const limit = searchParams.get('limit') || '4';

    if (!projectId) {
      return NextResponse.json({
        success: false,
        message: 'Project ID parameter is required'
      }, { status: 400 });
    }

    const id = parseInt(projectId);
    if (isNaN(id)) {
      return NextResponse.json({
        success: false,
        message: 'Invalid project ID format'
      }, { status: 400 });
    }

    const currentProject = projects.find(p => p.id === id);
    if (!currentProject) {
      return NextResponse.json({
        success: false,
        message: 'Project not found'
      }, { status: 404 });
    }

    // Filter out the current project and get similar projects
    // This is a simple implementation that could be improved with real similarity algorithms
    const suggestions = projects
      .filter(p => p.id !== id)
      .sort(() => 0.5 - Math.random()) // Simple random sorting
      .slice(0, parseInt(limit))

    return NextResponse.json({
      success: true,
      suggestions
    }, { status: 200 });
  } catch (error) {
    return NextResponse.json({
      success: false,
      message: 'Failed to get suggestions',
      error: String(error)
    }, { status: 500 });
  }
}
