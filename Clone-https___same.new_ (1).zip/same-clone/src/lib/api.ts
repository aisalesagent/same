import { Project, projects } from './data';

/**
 * Fetch all projects with optional filtering
 */
export async function getProjects(options?: { limit?: number; search?: string }): Promise<Project[]> {
  try {
    let result = [...projects];

    // Filter projects if search param exists
    if (options?.search) {
      const searchLower = options.search.toLowerCase();
      result = result.filter(project =>
        project.title.toLowerCase().includes(searchLower)
      );
    }

    // Limit results if limit param exists
    if (options?.limit) {
      result = result.slice(0, options.limit);
    }

    return result;
  } catch (error) {
    console.error('Error fetching projects:', error);
    return [];
  }
}

/**
 * Fetch a single project by ID
 */
export async function getProject(id: number): Promise<Project | null> {
  try {
    const project = projects.find(p => p.id === id);
    return project || null;
  } catch (error) {
    console.error(`Error fetching project ${id}:`, error);
    return null;
  }
}

/**
 * Fetch project suggestions
 */
export async function getProjectSuggestions(projectId: number, limit: number = 4): Promise<Project[]> {
  try {
    // Filter out the current project and get similar projects
    // This is a simple implementation that could be improved with real similarity algorithms
    return projects
      .filter(p => p.id !== projectId)
      .sort(() => 0.5 - Math.random()) // Simple random sorting
      .slice(0, limit);
  } catch (error) {
    console.error(`Error fetching suggestions for project ${projectId}:`, error);
    return [];
  }
}

/**
 * Search projects by query
 */
export async function searchProjects(query: string): Promise<{
  success: boolean;
  results: Project[];
  count: number;
  query: string;
}> {
  try {
    // Filter projects based on the query
    const results = projects.filter(project =>
      project.title.toLowerCase().includes(query.toLowerCase()) ||
      (project.description && project.description.toLowerCase().includes(query.toLowerCase()))
    );

    return {
      success: true,
      results,
      count: results.length,
      query
    };
  } catch (error) {
    console.error('Error searching projects:', error);
    return {
      success: false,
      results: [],
      count: 0,
      query
    };
  }
}
