// Define the Project type
export type Project = {
  id: number;
  title: string;
  imageSrc: string;
  userAvatarSrc?: string;
  timeAgo: string;
  promptUrl?: string;
  description?: string;
};

// Mock data for our projects
export const projects: Project[] = [
  {
    id: 1,
    title: "Clone menuiserie-roux.arduc.ch",
    imageSrc: "https://ext.same-assets.com/1725212416/3535583230.webp",
    userAvatarSrc: "https://ext.same-assets.com/410181739/4206228468.jpeg",
    timeAgo: "7 minutes ago",
    promptUrl: "#",
    description: "A perfect clone of menuiserie-roux.arduc.ch website with responsive design and elegant UI."
  },
  {
    id: 2,
    title: "Clone https://www.google.com/",
    imageSrc: "https://ext.same-assets.com/1725212416/2659677458.webp",
    userAvatarSrc: "https://ext.same-assets.com/410181739/4103370926.jpeg",
    timeAgo: "9 minutes ago",
    promptUrl: "#",
    description: "A pixel-perfect reproduction of Google's search homepage with all the essential elements."
  },
  {
    id: 3,
    title: "Developer Resume Project",
    imageSrc: "https://ext.same-assets.com/1725212416/1495607806.webp",
    userAvatarSrc: "https://ext.same-assets.com/4196393265/3927250020.jpeg",
    timeAgo: "about 14 hours ago",
    promptUrl: "#",
    description: "A resume chat GPT style where users can query a PDF CV and showcase real implementation of websites and software."
  },
  {
    id: 4,
    title: "Clone www.josephmueller.com",
    imageSrc: "https://ext.same-assets.com/1725212416/2411190104.webp",
    userAvatarSrc: "https://ext.same-assets.com/410181739/1462035136.png",
    timeAgo: "10 minutes ago",
    promptUrl: "#",
    description: "A faithful reproduction of josephmueller.com with clean, minimalist design and responsive layout."
  },
  {
    id: 5,
    title: "Clone facebook.com",
    imageSrc: "https://ext.same-assets.com/1725212416/1061424171.webp",
    timeAgo: "7 minutes ago",
    promptUrl: "#",
    description: "A complete Facebook UI clone with sidebar, newsfeed, and contact list using pure HTML, CSS and JS."
  },
  {
    id: 6,
    title: "Clone https://truyenhdt.com/",
    imageSrc: "https://ext.same-assets.com/1725212416/2881991819.webp",
    userAvatarSrc: "https://ext.same-assets.com/410181739/3291150859.jpeg",
    timeAgo: "10 minutes ago",
    promptUrl: "#",
    description: "A perfect copy of truyenhdt.com with all the original styling and functionality."
  },
  {
    id: 7,
    title: "Portfolio Website",
    imageSrc: "https://ext.same-assets.com/1725212416/1535026342.webp",
    userAvatarSrc: "https://ext.same-assets.com/410181739/1280690759.jpeg",
    timeAgo: "14 minutes ago",
    promptUrl: "#",
    description: "A beautiful portfolio website with search bar functionality and responsive design."
  },
  {
    id: 8,
    title: "Clone Mobile UI",
    imageSrc: "https://ext.same-assets.com/1725212416/2284608494.webp",
    userAvatarSrc: "https://ext.same-assets.com/410181739/1972865016.png",
    timeAgo: "12 minutes ago",
    promptUrl: "#",
    description: "A recreation of a mobile app interface with clean UI components and intuitive navigation."
  }
];
