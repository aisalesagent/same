"use client";

import Image from "next/image";
import Link from "next/link";
import { Card } from "@/components/ui/card";

interface ProjectCardProps {
  id: number;
  imageSrc: string;
  userAvatarSrc?: string;
  timeAgo: string;
  title: string;
  promptUrl?: string;
}

export default function ProjectCard({
  id,
  imageSrc,
  userAvatarSrc,
  timeAgo,
  title,
  promptUrl
}: ProjectCardProps) {
  return (
    <Card className="overflow-hidden border shadow-sm bg-card transition-all hover:shadow-md">
      <Link href={`/projects/${id}`} className="block">
        <div className="relative aspect-[4/3] w-full overflow-hidden">
          <Image
            src={imageSrc}
            alt={title}
            fill
            className="object-cover transition-all hover:scale-105"
          />
        </div>
      </Link>

      <div className="p-3 space-y-2">
        {userAvatarSrc && (
          <div className="flex items-center space-x-2">
            <Image
              src={userAvatarSrc}
              alt="User avatar"
              width={24}
              height={24}
              className="rounded-full"
            />
            <span className="text-xs text-muted-foreground">{timeAgo}</span>
          </div>
        )}

        {!userAvatarSrc && (
          <div className="flex items-center space-x-2">
            <span className="text-xs text-muted-foreground">{timeAgo}</span>
          </div>
        )}

        <h3 className="font-medium text-sm truncate">
          <Link href={`/projects/${id}`} className="hover:underline">
            {title}
          </Link>
        </h3>

        <div className="pt-1">
          <Link
            href={promptUrl || "#"}
            className="text-sm text-primary hover:underline"
          >
            Use prompt
          </Link>
        </div>
      </div>
    </Card>
  );
}
