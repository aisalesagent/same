"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Input } from "@/components/ui/input";
import { LinkIcon, ArrowUpIcon } from "lucide-react";

export default function SearchBar() {
  const [searchTerm, setSearchTerm] = useState("");
  const router = useRouter();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchTerm.trim())}`);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="relative w-full max-w-2xl mx-auto">
      <div className="relative flex items-center rounded-full border bg-white shadow-sm overflow-hidden">
        <Input
          type="text"
          placeholder="clone ycombinator"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-grow border-0 focus-visible:ring-0 focus-visible:ring-offset-0 placeholder:text-muted-foreground"
        />
        <div className="flex items-center mr-2 gap-1">
          <button
            type="button"
            className="p-2 rounded-full hover:bg-secondary text-muted-foreground"
            aria-label="Link"
          >
            <LinkIcon size={18} />
          </button>
          <button
            type="submit"
            className="p-2 rounded-full hover:bg-secondary text-muted-foreground"
            aria-label="Submit"
          >
            <ArrowUpIcon size={18} />
          </button>
        </div>
      </div>
    </form>
  );
}
