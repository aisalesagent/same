"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function Navbar() {
  return (
    <header className="w-full py-4 px-6 flex items-center justify-between">
      <div className="flex items-center">
        <Link href="/" className="text-2xl font-bold">
          same
        </Link>
      </div>

      <div className="flex items-center gap-4">
        <Button className="bg-[#20a77d] hover:bg-[#1a8a68] text-white">
          We're Hiring
        </Button>
        <Link href="/login" className="text-foreground hover:underline">
          Sign in
        </Link>
      </div>
    </header>
  );
}
